const $ = (id) => document.getElementById(id);
const state = { room: null, token: null, name: "", poll: null, seen: new Set() };

function apiUrl(path) {
  // Same-origin by default. For GitHub Pages, set window.ARMIN_API before this file loads.
  const base = window.ARMIN_API || "";
  return base.replace(/\/$/, "") + path;
}

async function request(path, options = {}) {
  const res = await fetch(apiUrl(path), { cache: "no-store", ...options });
  let data = {};
  try { data = await res.json(); } catch (_) {}
  if (!res.ok || data.ok === false) throw new Error(data.error || `HTTP ${res.status}`);
  return data;
}

function setStatus(text) { $("status").textContent = text; }
function setHomeMsg(text) { $("homeMsg").textContent = text; }
function saveState() { localStorage.setItem("armin_chat_state", JSON.stringify(state)); }
function clearState() { localStorage.removeItem("armin_chat_state"); }

function renderMessage(m) {
  if (state.seen.has(m.id)) return;
  state.seen.add(m.id);
  const el = document.createElement("div");
  el.className = "msg" + (m.name === state.name ? " me" : "");
  const name = document.createElement("div");
  name.className = "name";
  name.textContent = m.name;
  el.appendChild(name);
  if (m.type === "image") {
    const img = document.createElement("img");
    img.src = m.data;
    img.alt = "تصویر";
    img.loading = "lazy";
    el.appendChild(img);
  } else {
    const text = document.createElement("div");
    text.textContent = m.text;
    el.appendChild(text);
  }
  const t = document.createElement("div");
  t.className = "time";
  t.textContent = new Date(m.time * 1000).toLocaleTimeString("fa-IR", {hour:"2-digit", minute:"2-digit"});
  el.appendChild(t);
  $("messages").appendChild(el);
  $("messages").scrollTop = $("messages").scrollHeight;
}

async function poll() {
  if (!state.room || !state.token) return;
  try {
    const data = await request(`/api/messages?room=${encodeURIComponent(state.room)}&token=${encodeURIComponent(state.token)}`);
    data.messages.forEach(renderMessage);
    $("members").textContent = `👥 اعضا: ${data.members.join("، ")}`;
    setStatus("🟢 آنلاین");
  } catch (e) {
    setStatus("🔴 اتصال قطع شد");
  }
}

async function enterRoom(code, create = false) {
  const name = $("name").value.trim() || "مهمان";
  try {
    const data = create
      ? await request("/api/create", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name})})
      : await request("/api/join", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({name, room:code})});
    state.room = data.room;
    state.token = data.token;
    state.name = name;
    state.seen = new Set();
    saveState();
    history.replaceState(null, "", `?room=${encodeURIComponent(state.room)}`);
    $("roomLabel").textContent = state.room;
    $("home").classList.add("hidden");
    $("room").classList.remove("hidden");
    $("leaveBtn").classList.remove("hidden");
    $("messages").replaceChildren();
    setStatus("🟢 آنلاین");
    await poll();
    clearInterval(state.poll);
    state.poll = setInterval(poll, 1200);
  } catch (e) { setHomeMsg("❌ " + e.message); }
}

$("createBtn").onclick = () => enterRoom(null, true);
$("joinBtn").onclick = () => {
  const code = $("roomCode").value.trim();
  if (!/^\d{6}$/.test(code)) return setHomeMsg("کد اتاق باید ۶ رقمی باشد.");
  enterRoom(code, false);
};
$("sendForm").onsubmit = async (e) => {
  e.preventDefault();
  const input = $("text");
  const text = input.value.trim();
  if (!text) return;
  try {
    const data = await request("/api/send", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({room:state.room, token:state.token, type:"text", text})});
    renderMessage(data.message);
    input.value = "";
  } catch (e) { setStatus("❌ " + e.message); }
};

$("imageBtn").onclick = () => $("imageInput").click();
$("imageInput").onchange = () => {
  const file = $("imageInput").files[0];
  if (!file) return;
  if (file.size > 3 * 1024 * 1024) { setStatus("❌ عکس باید حداکثر ۳ مگابایت باشد"); return; }
  const reader = new FileReader();
  reader.onload = async () => {
    try {
      const data = await request("/api/send", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({room:state.room, token:state.token, type:"image", data:reader.result})});
      renderMessage(data.message);
    } catch (e) { setStatus("❌ " + e.message); }
    $("imageInput").value = "";
  };
  reader.readAsDataURL(file);
};

$("copyBtn").onclick = async () => {
  const url = location.href;
  try { await navigator.clipboard.writeText(url); setStatus("✅ لینک کپی شد"); }
  catch (_) { prompt("لینک اتاق:", url); }
};

$("qrBtn").onclick = () => {
  const dialog = $("qrDialog");
  $("qr").replaceChildren();
  const url = location.href;
  if (typeof QRCode === "undefined") {
    $("qr").textContent = "کتابخانه QR بارگذاری نشد.";
  } else {
    new QRCode($("qr"), {text:url, width:220, height:220, correctLevel:QRCode.CorrectLevel.M});
  }
  $("qrText").textContent = url;
  dialog.showModal();
};
$("closeQr").onclick = () => $("qrDialog").close();
$("leaveBtn").onclick = async () => {
  try { await request("/api/leave", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({room:state.room, token:state.token})}); } catch (_) {}
  clearInterval(state.poll); clearState(); location.href = location.pathname;
};

const params = new URLSearchParams(location.search);
const initialRoom = params.get("room");
if (initialRoom) $("roomCode").value = initialRoom;
try {
  const old = JSON.parse(localStorage.getItem("armin_chat_state") || "null");
  if (old && old.room && old.token && old.name && old.room === initialRoom) {
    Object.assign(state, old); enterRoom(state.room, false);
  }
} catch (_) {}
