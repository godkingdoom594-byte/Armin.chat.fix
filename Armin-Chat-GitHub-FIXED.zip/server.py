#!/usr/bin/env python3
import base64
import json
import os
import secrets
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

HOST = "0.0.0.0"
DEFAULT_PORT = 8765
MAX_MESSAGE = 2000
MAX_IMAGE_BYTES = 3 * 1024 * 1024
MAX_MESSAGES = 300
ROOT = Path(__file__).resolve().parent

rooms = {}
lock = threading.RLock()


def clean_text(value, limit):
    value = str(value or "").strip()
    return value[:limit]


def new_code():
    with lock:
        while True:
            code = f"{secrets.randbelow(1_000_000):06d}"
            if code not in rooms:
                return code


def new_token():
    return secrets.token_urlsafe(24)


def create_room(name):
    code = new_code()
    token = new_token()
    now = time.time()
    with lock:
        rooms[code] = {
            "created": now,
            "last_activity": now,
            "members": {token: clean_text(name, 30) or "مهمان"},
            "messages": [],
        }
    return code, token


def join_room(code, name):
    with lock:
        room = rooms.get(code)
        if room is None:
            return None
        token = new_token()
        room["members"][token] = clean_text(name, 30) or "مهمان"
        room["last_activity"] = time.time()
        return token


def auth_room(code, token):
    room = rooms.get(code)
    if not room or token not in room["members"]:
        return None
    return room


def add_message(code, token, text=None, image=None):
    with lock:
        room = auth_room(code, token)
        if room is None:
            return None
        msg = {
            "id": secrets.token_hex(8),
            "name": room["members"][token],
            "time": int(time.time()),
        }
        if image is not None:
            msg["type"] = "image"
            msg["data"] = image
        else:
            msg["type"] = "text"
            msg["text"] = clean_text(text, MAX_MESSAGE)
            if not msg["text"]:
                return None
        room["messages"].append(msg)
        room["messages"] = room["messages"][-MAX_MESSAGES:]
        room["last_activity"] = time.time()
        return msg


def cleanup_loop():
    while True:
        time.sleep(60)
        cutoff = time.time() - 3600
        with lock:
            for code in list(rooms):
                room = rooms[code]
                if not room["members"] and room["last_activity"] < cutoff:
                    del rooms[code]


def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def find_port(start=DEFAULT_PORT):
    for port in range(start, start + 50):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((HOST, port))
                return port
            except OSError:
                pass
    raise RuntimeError("No free port found")


class Handler(BaseHTTPRequestHandler):
    server_version = "ArminChat/1.0"

    def log_message(self, fmt, *args):
        return

    def send_json(self, payload, status=200):
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def send_bytes(self, raw, content_type, status=200):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_IMAGE_BYTES + 100_000:
            raise ValueError("request too large")
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8")) if raw else {}

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        if path == "/api/ping":
            self.send_json({"ok": True, "server": "Armin Chat", "time": int(time.time())})
            return
        if path == "/api/messages":
            q = parse_qs(parsed.query)
            code = q.get("room", [""])[0]
            token = q.get("token", [""])[0]
            with lock:
                room = auth_room(code, token)
                if room is None:
                    self.send_json({"ok": False, "error": "اتاق یا نشست نامعتبر است"}, 401)
                    return
                messages = list(room["messages"])
                members = list(room["members"].values())
            self.send_json({"ok": True, "messages": messages, "members": members})
            return
        if path == "/" or path == "/index.html":
            self.serve_file("index.html", "text/html; charset=utf-8")
            return
        if path in ("/app.js", "/style.css", "/README.md"):
            types = {"/app.js": "text/javascript; charset=utf-8", "/style.css": "text/css; charset=utf-8", "/README.md": "text/plain; charset=utf-8"}
            self.serve_file(path.lstrip("/"), types[path])
            return
        self.send_json({"ok": False, "error": "Not found"}, 404)

    def serve_file(self, name, content_type):
        target = (ROOT / name).resolve()
        if target.parent != ROOT or not target.is_file():
            self.send_json({"ok": False, "error": "File not found"}, 404)
            return
        self.send_bytes(target.read_bytes(), content_type)

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            data = self.read_json()
        except Exception as exc:
            self.send_json({"ok": False, "error": str(exc)}, 400)
            return

        if parsed.path == "/api/create":
            code, token = create_room(data.get("name", "مهمان"))
            self.send_json({"ok": True, "room": code, "token": token})
            return

        if parsed.path == "/api/join":
            code = clean_text(data.get("room"), 6)
            name = clean_text(data.get("name"), 30)
            token = join_room(code, name)
            if token is None:
                self.send_json({"ok": False, "error": "اتاق پیدا نشد"}, 404)
                return
            self.send_json({"ok": True, "room": code, "token": token})
            return

        if parsed.path == "/api/send":
            code = clean_text(data.get("room"), 6)
            token = clean_text(data.get("token"), 100)
            if data.get("type") == "image":
                image = str(data.get("data", ""))
                if not image.startswith("data:image/"):
                    self.send_json({"ok": False, "error": "فرمت عکس نامعتبر است"}, 400)
                    return
                try:
                    header, encoded = image.split(",", 1)
                    if len(base64.b64decode(encoded, validate=True)) > MAX_IMAGE_BYTES:
                        raise ValueError
                except Exception:
                    self.send_json({"ok": False, "error": "عکس باید حداکثر ۳ مگابایت باشد"}, 400)
                    return
                msg = add_message(code, token, image=image)
            else:
                msg = add_message(code, token, text=data.get("text"))
            if msg is None:
                self.send_json({"ok": False, "error": "ارسال پیام ناموفق بود"}, 400)
                return
            self.send_json({"ok": True, "message": msg})
            return

        if parsed.path == "/api/leave":
            code = clean_text(data.get("room"), 6)
            token = clean_text(data.get("token"), 100)
            with lock:
                room = rooms.get(code)
                if room and token in room["members"]:
                    del room["members"][token]
                    room["last_activity"] = time.time()
                    self.send_json({"ok": True})
                    return
            self.send_json({"ok": False, "error": "نشست پیدا نشد"}, 404)
            return

        self.send_json({"ok": False, "error": "Not found"}, 404)


def main():
    port = find_port()
    server = ThreadingHTTPServer((HOST, port), Handler)
    threading.Thread(target=cleanup_loop, daemon=True).start()
    ip = local_ip()
    print("=" * 52)
    print("💬 Armin Chat server started")
    print(f"Local: http://127.0.0.1:{port}")
    print(f"LAN:   http://{ip}:{port}")
    print("📷 Image messages: up to 3 MB")
    print("=" * 52)
    print("Ctrl+C to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nServer stopped.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
