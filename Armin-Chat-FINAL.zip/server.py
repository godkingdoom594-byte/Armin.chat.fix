from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
import json,os,secrets,time,threading
HOST='0.0.0.0';PORT=8765;ROOT=os.path.dirname(os.path.abspath(__file__));rooms={};lock=threading.Lock();MAX=500
class H(BaseHTTPRequestHandler):
 def send(self,code,data,ctype='application/json'):
  raw=data if isinstance(data,bytes) else data.encode();self.send_response(code);self.send_header('Content-Type',ctype);self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
 def body(self):
  n=int(self.headers.get('Content-Length','0'));return json.loads(self.rfile.read(n) or b'{}')
 def do_GET(self):
  p=self.path.split('?',1)[0]
  if p=='/':return self.file('index.html','text/html; charset=utf-8')
  if p in ['/app.js','/style.css']:return self.file(p[1:],'text/javascript; charset=utf-8' if p.endswith('.js') else 'text/css; charset=utf-8')
  if p=='/api/messages':
   from urllib.parse import parse_qs,urlparse
   r=parse_qs(urlparse(self.path).query).get('room',[''])[0]
   with lock:d=rooms.get(r)
   if not d:return self.send(404,json.dumps({'ok':False,'error':'اتاق پیدا نشد'},ensure_ascii=False))
   return self.send(200,json.dumps({'ok':True,'messages':d['messages'],'members':list(d['members'].values())},ensure_ascii=False))
  return self.send(404,'Not found','text/plain')
 def file(self,n,ct):
  try:
   with open(os.path.join(ROOT,n),'rb') as f:return self.send(200,f.read(),ct)
  except FileNotFoundError:return self.send(404,b'Not found','text/plain')
 def do_POST(self):
  try:d=self.body()
  except:return self.send(400,json.dumps({'ok':False,'error':'JSON نامعتبر'}))
  p=self.path.split('?',1)[0]
  if p=='/api/create':
   name=str(d.get('name','')).strip()[:30]
   if not name:return self.send(400,json.dumps({'ok':False,'error':'نام لازم است'}))
   with lock:
    code=str(secrets.randbelow(900000)+100000)
    while code in rooms:code=str(secrets.randbelow(900000)+100000)
    rooms[code]={'members':{},'messages':[]};rooms[code]['members'][secrets.token_hex(8)]=name
   return self.send(200,json.dumps({'ok':True,'room':code},ensure_ascii=False))
  if p=='/api/join':
   code=str(d.get('room','')).strip();name=str(d.get('name','')).strip()[:30]
   with lock:
    if code not in rooms:return self.send(404,json.dumps({'ok':False,'error':'اتاق پیدا نشد'},ensure_ascii=False))
    rooms[code]['members'][secrets.token_hex(8)]=name
   return self.send(200,json.dumps({'ok':True,'room':code},ensure_ascii=False))
  if p=='/api/send':
   code=str(d.get('room','')).strip();name=str(d.get('name','')).strip()[:30];typ=d.get('type','text')
   with lock:
    if code not in rooms:return self.send(404,json.dumps({'ok':False,'error':'اتاق پیدا نشد'},ensure_ascii=False))
    if typ=='image':
     data=str(d.get('data',''))
     if len(data)>4_200_000:return self.send(413,json.dumps({'ok':False,'error':'عکس بزرگ است'}))
     msg={'name':name,'type':'image','data':data,'time':time.time()}
    else:msg={'name':name,'type':'text','text':str(d.get('text',''))[:1000],'time':time.time()}
    rooms[code]['messages'].append(msg);rooms[code]['messages']=rooms[code]['messages'][-MAX:]
   return self.send(200,json.dumps({'ok':True}))
  return self.send(404,json.dumps({'ok':False,'error':'Not found'}))
 def log_message(self,*a):pass
def main():
 global PORT
 s=None
 for p in range(PORT,PORT+20):
  try:s=ThreadingHTTPServer((HOST,p),H);PORT=p;break
  except OSError:continue
 if not s:raise RuntimeError('هیچ پورتی آزاد نیست')
 print('='*52);print('Armin Chat server');print('Local: http://127.0.0.1:%d'%PORT);print('='*52);s.serve_forever()
if __name__=='__main__':main()
