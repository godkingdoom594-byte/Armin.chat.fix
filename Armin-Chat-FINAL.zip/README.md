# Armin Chat

چت‌روم چندنفره ساده با Python و HTML/CSS/JavaScript.

## اجرا در Pydroid 3

```bash
python server.py
```

سپس روی همان دستگاه `http://127.0.0.1:8765` را باز کن.

برای دستگاه‌های دیگر در همان Wi‑Fi، IP دستگاه اجراکننده را به‌جای 127.0.0.1 استفاده کن.

## GitHub Pages

GitHub Pages فقط فایل‌های فرانت‌اند را سرو می‌کند و `server.py` را اجرا نمی‌کند. برای چت چندنفره واقعی، Python server باید روی یک دستگاه/سرور قابل دسترس اجرا شود.

## فایل‌ها

- `index.html` رابط کاربری
- `app.js` منطق مرورگر
- `style.css` ظاهر
- `server.py` API و سرور چت
- `README.md` راهنما
